package com.xj.base.common;

public interface Constats {
	
	public String CURRENTUSER = "_currentUser";

}
